//
//  TCVersion.h
//  TrueSDK
//
//  Created by Aleksandar Mihailovski on 2017-03-23.
//  Copyright © 2017 True Software Scandinavia AB. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *TrueSDKVersion;
FOUNDATION_EXPORT NSString *TrueSDKApiVersion;
