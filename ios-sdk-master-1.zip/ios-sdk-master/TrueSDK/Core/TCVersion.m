//
//  TCVersion.m
//  TrueSDK
//
//  Created by Aleksandar Mihailovski on 2017-03-23.
//  Copyright © 2017 True Software Scandinavia AB. All rights reserved.
//

#import "TCVersion.h"

NSString *TrueSDKVersion = @"0.1";
NSString *TrueSDKApiVersion = @"1.0";
