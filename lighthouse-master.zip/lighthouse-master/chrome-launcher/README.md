# Chrome Launcher [![NPM chrome-launcher package](https://img.shields.io/npm/v/chrome-launcher.svg)](https://npmjs.org/package/chrome-launcher)

Launch Google Chrome with ease from node. Package moved to https://npmjs.org/package/chrome-launcher.
