// this is only true when in a browser-like environment
// (or someone seriously messed up)
export default (typeof window !== 'undefined');
